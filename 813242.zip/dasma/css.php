<?php


header("Content-type: text/css; charset: UTF-8");
?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<!--
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap4.min.js"></script> 
-->


 <!-- body, html {
    height: 100%;
    margin: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    font-family: Arial, sans-serif;
    background-color: gray;
} -->

        body {
            margin: 0;
            display: flex;
            background-color: #f2f2f2;
        }

        .sidebarr {
            margin: 0;
            padding: 0;
            width: 200px;
            background-color: #333;
            position: fixed;
            height: 100%;
            overflow: auto;
            padding-top: 50px;
        }

        .sidebarr a {
            display: block;
            color: white;
            padding: 16px;
            text-decoration: none;
        }

        .sidebarr a:hover {
            background-color: #ddd;
            color: black;
        }

        .content {
            margin-left: 200px;
            padding: 1px 16px;
            height: auto;
            margin-top:50px;
            width: 100%;
        }

        @media screen and (max-width: 700px) {
            .sidebarr {
                width: 100%;
                height: auto;
                position: relative;
            }
            .sidebarr a {float: left;}
            .content {margin-left: 0;}
        }

        @media screen and (max-width: 400px) {
            .sidebarr a {
                text-align: center;
                float: none;
            }
        }

        .topnav {
            overflow: hidden;
            background-color: #212121;
            z-index: 1000;
            top: 0;
            width: 100%;
            position: fixed;
        }

        .topnav a {
            float: right;
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
            font-size: 17px;
        }

        .topnav a:hover {
            background-color: #ddd;
            color: black;
        }

        .topnav img.active {
            color: black;
            height: 40px;
            float: left;
            padding: 5px;
        }

        table {
            padding-top: 50px
            width: 100%;
            border-collapse: collapse;
            
        }
        thead {
            background-color: #00ABF6;
        }

        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
       