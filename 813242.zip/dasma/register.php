<?php
session_start();
include 'conn.php';


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $departments = isset($_POST['departments']) ? $_POST['departments'] : [];

    if ($password !== $confirm_password) {
        echo "<script>";
        echo "window.alert('password do not match!');";
        echo "window.location.href='register.php';";
        echo "</script>";
        exit;
    }

    $username = $conn->real_escape_string($username);
    $password = $conn->real_escape_string($password);

    $departments_str = implode(",", $departments);
    $dept_codes = $departments_str;

    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    $sql = "SELECT * FROM tbl_users WHERE username='$username'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo "<script>";
        echo "window.alert('Username already taken.');";
        echo "</script>";
    } else {
        $sql = "INSERT INTO tbl_users (username, password, dept_code) VALUES ('$username', '$hashed_password', '$dept_codes')";
        if ($conn->query($sql) === TRUE) {
            echo "Registration successful.";
            header("Location: index.php");
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" type="text/css" href="cssindex.php">
    <style>
        .checkbox-dropdown input[type="checkbox"] {
            margin-right: 10px;
        }

        .checkbox-dropdown label {
            display: flex;
            align-items: center;
            padding: 5px 10px;
            cursor: pointer;
        }

        .checkbox-dropdown label:hover {
            background-color: #f1f1f1;
        }

        .dropdown-checkboxes {
            position: relative;
        }

        .dropdown-btn {

            cursor: pointer;
            text-align: left;
        }

        .checkbox-dropdown {
            display: none;
            position: absolute;
            top: 100%;
            left: 0;
            width: 100%;
            max-height: 200px;
            overflow-y: auto;
            border: 1px solid #ccc;
            background: white;
            z-index: 1;
        }
    </style>
</head>
<body>
    <div class="loginOuter">
        <div class="login register">
            <form class="loginForm" method="POST" action="">
                <h1 class="h1loginForm">REGISTER</h1>
                <label class="loginLabel">Username</label>
                <input class="logInput" type="text" name="username" required>
                <label class="loginLabel">Password</label>
                <input class="logInput" type="password" name="password" required>
                <label class="loginLabel">Confirm Password</label>
                <input class="logInput" type="password" name="confirm_password" required>
                <label class="loginLabel">Department</label>
                <div class="dropdown-checkboxes">
                    <div class="dropdown-btn logInput" onclick="toggleDropdown()">Select Department</div>
                    <div class="checkbox-dropdown">
                        <?php
                        $sql = "SELECT dept_code, dept_desc FROM tbl_department";
                        $result = $conn->query($sql);

                        if ($result->num_rows > 0) {
                            while($row = $result->fetch_assoc()) {
                                echo "<label style= 'color:black;'><input type='checkbox' name='departments[]' value='".$row['dept_code']."'>".$row['dept_desc']."</label>";
                            }
                        } else {
                            echo "<p>No departments available</p>";
                        }
                        $conn->close();
                        ?>
                    </div>
                </div>
                <button class="loginButton" type="submit">Register</button>
                <a class="loginButton button-link" href="index.php">Log In</a>
            </form>
        </div>
    </div>
</body>
</html>

<script>
        function toggleDropdown() {
            var dropdown = document.querySelector('.checkbox-dropdown');
            dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
        }

        document.addEventListener('click', function(event) {
            var isClickInside = document.querySelector('.dropdown-checkboxes').contains(event.target);
            if (!isClickInside) {
                document.querySelector('.checkbox-dropdown').style.display = 'none';
            }
        });
    </script>
